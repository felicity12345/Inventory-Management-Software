<?php require_once 'php_action/manage.php'; ?>

<!DOCTYPE html>
<html>
<head>

	<title>Inventory Management System</title>

	<!-- bootstrap -->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	<!-- bootstrap theme-->
	<link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	<!-- font awesome -->
	<link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">

  <!-- custom css -->
  <link rel="stylesheet" href="custom/css/custom.css">

	<!-- DataTables -->
  <link rel="stylesheet" href="assests/plugins/datatables/jquery.dataTables.min.css">

  <!-- file input -->
  <link rel="stylesheet" href="assests/plugins/fileinput/css/fileinput.min.css">

  <!-- jquery -->
	<script src="assests/jquery/jquery.min.js"></script>
  <!-- jquery ui -->  
  <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
  <script src="assests/jquery-ui/jquery-ui.min.js"></script>

  <!-- bootstrap js -->
	<script src="assests/bootstrap/js/bootstrap.min.js"></script>

</head>
<body>
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
     <a class="navbar-brand">IMS</a>
      <div class="navbar-header">
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
	    </div>

      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">      
       <ul class="nav navbar-nav navbar-right">        
       <li class="navDashboard"><a class="nav-link" href="index.php">Dashboard</a></li>       
        
        <?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
          <li class="navBrand"><a class="nav-link" href="brand.php">Brand</a></li>
		    <?php } ?>

        <?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
          <li class="navCategories"><a class="nav-link" href="categories.php">Category</a></li>
		    <?php } ?>
		   
        <?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
          <li class="navProduct"><a class="nav-link" href="product.php">Product</a></li>
		    <?php } ?>

        <?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
          <li class="navAddOrder"><a class="nav-link" href="orders.php?o=add">Add Orders</a></li>
		    <?php } ?>
		   
        <?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
          <li class="navManageOrder"><a class="nav-link" href="orders.php?o=manord">Manage Orders</a></li>
		    <?php } ?>

        <?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
          <li class="navReport"><a class="nav-link" href="report.php">Report</a></li>
		    <?php } ?>
      		
	  
        <li class="dropdown" id="navSetting">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <i class="glyphicon glyphicon-user"></i> <span class="caret"></span></a>
          <ul class="dropdown-menu">    
			<?php if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
        <li class="navSetting"><a class="nav-link" href="setting.php">Setting</a></li>
        <li class="navUser"><a class="nav-link" href="user.php">Add User</a></li>
      <?php } ?>      
            <li class="navLogout"><a class="nav-link" href="logout.php">Logout</a></li>
          </ul>
        </li>        
           
      </ul>
    </div>
  </div>
	</nav>

