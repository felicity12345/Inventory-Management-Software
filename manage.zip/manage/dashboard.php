<?php require_once 'includes/header.php'; ?>

<?php 

$sql = "SELECT * FROM product WHERE status = 1";
$query = $connect->query($sql);
$countProduct = $query->num_rows;

$orderSql = "SELECT * FROM orders WHERE order_status = 1";
$orderQuery = $connect->query($orderSql);
$countOrder = $orderQuery->num_rows;


$lowStockSql = "SELECT * FROM product WHERE quantity <= 3 AND status = 1";
$lowStockQuery = $connect->query($lowStockSql);
$countLowStock = $lowStockQuery->num_rows;


$connect->close();

?>

<div class="row">
	<?php  if(isset($_SESSION['userId']) && $_SESSION['userId']==1) { ?>
		
	

	<div class="container">
		<div class="row">
		<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Total Product</h4>
						<p class="card-text"><h2>Here you can view and manage your Total product<h2></p>
						<a href="product.php" class="btn btn-primary">
						<span class="badge pull pull-right"><?php echo $countLowStock; ?></span>	

						</a>
					</div>
				</div>
			</div>
	


			
			<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Low Stock</h4>
						<p class="card-text"><h2>Here you can view Low Stock<h2></p>
						<a href="product.php" class="btn btn-primary">
						<span class="badge pull pull-right"><?php echo $countLowStock; ?></span>	

						</a>
					</div>
				</div>
			</div>
	
            
			<?php } ?>  
			<div class="col-md-4">
				<div class="card">
						<div class="card-body">
						<h4 class="card-title">Total Orders</h4>
						<p class="card-text"><h2>Here you can view and manage your Total Orders<h2></p>
						<a href="orders.php?o=manord" class="btn btn-primary">
						<span class="badge pull pull-right"><?php echo $countLowStock; ?></span>	

						</a>
					</div>
				</div>
			</div>
</div> 
</script>
<?php require_once 'includes/footer.php'; ?>