<?php 
// Initialize the session
session_start();

// Check if the user is already logged in, if yes then redirect him to welcome page

if(isset($_SESSION["userId"])  && $_SESSION["userId"]=== true){
	header('location:dashboard.php');
	exit;		
}
// Include connect file
require_once 'php_action/db_connect.php';

$errors = array();
// Processing form data when form is submitted
if($_POST) {		
    $username = $_POST['username'];
	$password = $_POST['password'];

    // Check if username and  password is empty
	if(empty($username) || empty($password)) {
		if($username == "") {
			$errors[] = "Username is required";
		} 
       if($password == "") {
			$errors[] = "Password is required";
		}
		// Prepare a select statement
	} else {
		$sql = "SELECT * FROM users WHERE username = '$username'";
		$result = $connect->query($sql);

		if($result->num_rows == 1) {
			$password = md5($password);
			// exists
			$mainSql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
			$mainResult = $connect->query($mainSql);

			if($mainResult->num_rows == 1) {
				$value = $mainResult->fetch_assoc();
				$user_id = $value['user_id'];

				// set session
				$_SESSION['userId'] = $user_id;

				// Redirect user to dashboard page
				header('location:dashboard.php');	
			} else{
				
				$errors[] = "Incorrect username/password combination";
			} // Password is not valid, display a generic error message

		} else {		
			$errors[] = "Username doesnot exists";		
		} 
	} // Username doesn't exist, display a generic error message
	
} 
?>



<!DOCTYPE html>
<html>
    <head>
	  <title>Inventory Management System</title>

	   <!-- bootstrap -->
	   <link rel="stylesheet" href="assests/bootstrap/css/bootstrap.min.css">
	    <!-- bootstrap theme-->
	    <link rel="stylesheet" href="assests/bootstrap/css/bootstrap-theme.min.css">
	   <!-- font awesome -->
	   <link rel="stylesheet" href="assests/font-awesome/css/font-awesome.min.css">

      <!-- custom css -->
      <link rel="stylesheet" href="custom/css/custom.css">	

       <!-- jquery -->
	   <script src="assests/jquery/jquery.min.js"></script>
       <!-- jquery ui -->  
       <link rel="stylesheet" href="assests/jquery-ui/jquery-ui.min.css">
       <script src="assests/jquery-ui/jquery-ui.min.js"></script>
       <!-- bootstrap js -->
	   <script src="assests/bootstrap/js/bootstrap.min.js"></script>
    </head>

   <style>
            body{ font: 14px sans-serif;
              display: flex;
              flex-direction: column;
              justify-content: center;
              padding:1.7rem ;
              margin:0;
              align-items: center;
              height: 100vh;
              font: size 18px;
              background: url(./assests/images/inventory/002.jpg);
              background-size:cover;
            }          
    </style>

    <body>
	    <div class="container">
		   <div class="row vertical">
			 <div class="col-md-5 col-md-offset-4">
				<div class="panel panel-info">
					<div class="panel-heading">
						<h3 class="panel-title">Please Sign in</h3>
					</div>
	   <div class="panel-body">

		<div class="messages">
			<?php if($errors) {
			   foreach ($errors as $key => $value) {
					echo '<div class="alert alert-warning" role="alert">
					<i class="glyphicon glyphicon-exclamation-sign"></i>
					'.$value.'</div>';										
				}
			} ?>
	   </div>

		<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post"> <div class="form-group">
						
			<div class="form-group">
				<label for="username" class="col-sm-3 control-label">Username</label>
			    <div class="col-sm-25">
				    <input type="text" class="form-control" id="username" name="username" placeholder="Username" autocomplete="off" />
			    </div>
		    </div>
			<div class="form-group">
				<label for="password" class="col-sm-3 control-label">Password</label>
				<div class="col-sm-25">
					<input type="password" class="form-control" id="password" name="password" placeholder="Password" autocomplete="off" />
				</div>
		    </div>								
			<div class="form-group">
				<div class="col-sm-offset-3 col-sm-25">
				<button type="submit" class="btn btn-primary"> <i class="glyphicon glyphicon-ok-sign"></i> Login </button>

					
				</div>
			</div>
			</fieldset>
		</form>
				
    </body>
</html>







	