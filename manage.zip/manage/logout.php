<?php 

require_once 'php_action/manage.php';

// Unset all of the session variables
session_unset(); 

// destroy the session 
session_destroy(); 

// Redirect to login page
header('location:index.php');	
exit;

?>
