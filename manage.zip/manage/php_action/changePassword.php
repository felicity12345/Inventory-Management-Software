<?php 
    // require manage file
require_once 'manage.php';
   
//   Processing form data when form is submitted
 if($_POST) {
   $valid['success'] = array('success' => false, 'messages' => array());
    
	//  Define variables and initialize with empty values
    $currentPassword = md5($_POST['password']);
	$newPassword = md5($_POST['npassword']);
	$conformPassword = md5($_POST['cpassword']);
	$userId = $_POST['user_id'];

	$sql ="SELECT * FROM users WHERE user_id = {$userId}";
	$query = $connect->query($sql);
	$result = $query->fetch_assoc();

	 // Check input errors before updating the database

	if($currentPassword == $result['password']) {

		if($newPassword == $conformPassword) {

	        //  confirm password Validation
           $updateSql = "UPDATE users SET password = '$newPassword' WHERE user_id = {$userId}";
			if($connect->query($updateSql) === TRUE) {
				$valid['success'] = true;
				$valid['messages'] = "Successfully Updated password"; 		
			} else {
				$valid['success'] = false;
				$valid['messages'] = "Error occur while updating the password";	
			}
     
		} else {
			$valid['success'] = false;
			$valid['messages'] = "New password does not match with Conform password";
		}

	} else {
		$valid['success'] = false;
		$valid['messages'] = "Current password is incorrect";
		
	}
    // Close statement
     $connect->close();

	echo json_encode($valid);

}

?>