<?php 
    // require manage file
require_once 'manage.php';

//   Processing form data when form is submitted
if($_POST) {

	$valid['success'] = array('success' => false, 'messages' => array());
	
	//  Define variables and initialize with empty values
    $username = $_POST['username'];
	$userId = $_POST['user_id'];

	$sql = "UPDATE users SET username = '$username' WHERE user_id = {$userId}";
	if($connect->query($sql) === TRUE) {
		$valid['success'] = true;
		$valid['messages'] = "Successfully Updated username";	
	} else {
		$valid['success'] = false;
		$valid['messages'] = "Error while updating user information";
	}
    // Close statement
     $connect->close();

	echo json_encode($valid);

}

?>